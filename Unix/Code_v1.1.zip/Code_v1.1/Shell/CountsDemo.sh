wc -l file1.txt

wc -l < file1.txt

wc -w file1.txt

awk '{print $1}' file1.txt

awk '$3 > 100' file1.txt

awk '{sum += $2} END {print sum}' file1.txt

awk 'END {print NR}' file1.txt

sed 's/oldword/newword/g' file1.txt

sed '3d' file1.txt

sed '2a\New line added after line 2' file1.txt

awk '$2=="Apple" {print $1, $3}' file1.txt
