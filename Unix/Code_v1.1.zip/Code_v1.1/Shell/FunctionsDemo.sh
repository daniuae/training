greet() {
    echo "Hello, $1"
}
greet 'Anna'