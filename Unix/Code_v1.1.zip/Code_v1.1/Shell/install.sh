#!/bin/bash

export PGUSER=postgres
psql <<- SHELL
  CREATE USER docker;
  CREATE DATABASE "adventureworks";
  GRANT ALL PRIVILEGES ON DATABASE "adventureworks" TO docker;
SHELL
cd /data
psql -d adventureworks < install.sql
