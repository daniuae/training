#!/bin/bash

# Set DB variables
HOST="localhost"
PORT="5432"
DB="NorthwindDB"
USER="postgres"

export PGUSER=postgres
psql <<- SHELL
  # CREATE USER docker;
  # GRANT ALL PRIVILEGES ON DATABASE "Adventureworks" TO docker;
SHELL
cd /data
psql -d Adventureworks < ~/data/install.sql