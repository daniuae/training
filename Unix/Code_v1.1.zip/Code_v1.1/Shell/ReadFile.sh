while read line; do
    echo $line
done < myfile.txt

echo $line
