#!/bin/bash
if [ "$a" = "$b" ]; then
    echo "Equal"
fi
