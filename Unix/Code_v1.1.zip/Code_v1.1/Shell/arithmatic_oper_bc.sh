#!/bin/bash
a=10.5
b=4.2

sum=$(echo "$a + $b" | bc)
diff=$(echo "$a - $b" | bc)
prod=$(echo "$a * $b" | bc)
quot=$(echo "scale=2; $a / $b" | bc)

echo "Sum: $sum"
echo "Difference: $diff"
echo "Product: $prod"
echo "Quotient: $quot"
