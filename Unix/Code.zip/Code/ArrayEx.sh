arr=(a b c)
echo ${arr[1]}